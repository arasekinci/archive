# iPhone 15 Pro

Bu proje, patika.dev işbirliği içinde eğitim amacıyla hazırlanmıştır. iPhone 15 Pro'nun tanıtım sayfasının basit bir HTML/CSS/JavaScript yapısıdır.

## Nasıl İndirilir

Projenin dosyalarını bilgisayarınıza doğrudan indirin: [patika/iphone-15-pro.zip](/patika/iphone-15-pro.zip)

Projeyi bir tarayıcıda açmak için, `index.html` dosyasına çift tıklayın veya sağ tıklayıp "Tarayıcıda aç" seçeneğini kullanın.

## Önizleme

![Önizleme](preview.jpg)

*Bu proje sadece statik bir HTML sayfasıdır ve herhangi bir etkileşim veya gerçek veri alışverişi içermez. Yalnızca bir tasarım örneği olarak sunulmuştur.*

## İletişim

Herhangi bir sorunuz veya geri bildiriminiz varsa, lütfen arasekinci@outlook.com adresine e-posta gönderin.