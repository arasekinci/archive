# Beginner Frontend Course

Bu proje, patika.dev işbirliği içinde eğitim amacıyla hazırlanmıştır. İçerisinde temel düzeyde eğitim materyalleri bulunmaktadır.

## Nasıl İndirilir

Projenin dosyalarını bilgisayarınıza doğrudan indirin: [patika/beginner-frontend-course.zip](/patika/beginner-frontend-course.zip)

Projeyi bir tarayıcıda açmak için, `index.html` dosyasına çift tıklayın veya sağ tıklayıp "Tarayıcıda aç" seçeneğini kullanın.

## İletişim

Herhangi bir sorunuz veya geri bildiriminiz varsa, lütfen arasekinci@outlook.com adresine e-posta gönderin.